// B&R Presentation JavaScript - Skrócona wersja

class BRPresentation {
    constructor() {
        this.currentSlide = 1;
        this.totalSlides = 9; // Zmieniono z 8 na 9
        this.slides = document.querySelectorAll('.slide');
        this.prevBtn = document.querySelector('.prev-btn');
        this.nextBtn = document.querySelector('.next-btn');
        this.progressFill = document.querySelector('.progress-fill');
        this.currentSlideElement = document.querySelector('.current-slide');
        this.totalSlidesElement = document.querySelector('.total-slides');
        this.init();
    }

    init() {
        this.updateSlideDisplay();
        this.updateProgressBar();
        this.updateNavigationButtons();
        this.addEventListeners();
        document.body.focus();
        document.body.style.overflow = 'hidden';
        console.log('B&R Presentation initialized');
    }

    addEventListeners() {
        if (this.prevBtn) this.prevBtn.addEventListener('click', () => this.previousSlide());
        if (this.nextBtn) this.nextBtn.addEventListener('click', () => this.nextSlide());
        
        document.addEventListener('keydown', (e) => this.handleKeyPress(e));
        
        let startX = 0;
        let endX = 0;
        
        document.addEventListener('touchstart', (e) => {
            startX = e.touches[0].clientX;
        });
        
        document.addEventListener('touchend', (e) => {
            endX = e.changedTouches[0].clientX;
            this.handleSwipe(startX, endX);
        });
        
        document.addEventListener('contextmenu', (e) => e.preventDefault());
        window.addEventListener('resize', () => this.handleResize());
    }

    handleKeyPress(e) {
        switch(e.key) {
            case 'ArrowRight':
            case ' ':
            case 'PageDown':
                e.preventDefault();
                this.nextSlide();
                break;
            case 'ArrowLeft':
            case 'PageUp':
                e.preventDefault();
                this.previousSlide();
                break;
            case 'Home':
                e.preventDefault();
                this.goToSlide(1);
                break;
            case 'End':
                e.preventDefault();
                this.goToSlide(this.totalSlides);
                break;
            case 'Escape':
                e.preventDefault();
                this.toggleFullscreen();
                break;
            default:
                if (e.key >= '1' && e.key <= '8') {
                    const slideNumber = parseInt(e.key);
                    if (slideNumber <= this.totalSlides) {
                        e.preventDefault();
                        this.goToSlide(slideNumber);
                    }
                }
                break;
        }
    }

    handleSwipe(startX, endX) {
        const threshold = 50;
        const diff = startX - endX;
        
        if (Math.abs(diff) > threshold) {
            if (diff > 0) {
                this.nextSlide();
            } else {
                this.previousSlide();
            }
        }
    }

    handleResize() {
        const slides = document.querySelectorAll('.slide');
        slides.forEach(slide => {
            slide.offsetHeight;
        });
    }

    nextSlide() {
        if (this.currentSlide < this.totalSlides) {
            this.goToSlide(this.currentSlide + 1);
        }
    }

    previousSlide() {
        if (this.currentSlide > 1) {
            this.goToSlide(this.currentSlide - 1);
        }
    }

    goToSlide(slideNumber) {
        if (slideNumber < 1 || slideNumber > this.totalSlides) {
            return;
        }

        const previousSlide = this.currentSlide;
        this.currentSlide = slideNumber;
        
        this.animateSlideTransition(previousSlide, slideNumber);
        this.updateSlideDisplay();
        this.updateProgressBar();
        this.updateNavigationButtons();
        this.announceSlideChange();
    }

    animateSlideTransition(fromSlide, toSlide) {
        const slides = document.querySelectorAll('.slide');
        
        slides.forEach(slide => {
            slide.classList.remove('active', 'prev');
        });
        
        if (fromSlide >= 1 && fromSlide <= this.totalSlides) {
            const currentSlide = slides[fromSlide - 1];
            if (currentSlide) {
                currentSlide.classList.add('prev');
            }
        }
        
        setTimeout(() => {
            const newSlide = slides[toSlide - 1];
            if (newSlide) {
                newSlide.classList.add('active');
                this.addSlideSpecificEffects(toSlide);
            }
        }, 50);
    }

    addSlideSpecificEffects(slideNumber) {
        switch(slideNumber) {
            case 1:
                this.animateTeamSections();
                break;
            case 2:
                this.animateAgendaItems();
                break;
            case 5:
                this.animateDemoPlaceholder();
                break;
            case 7:
                this.animateResults();
                break;
            default:
                this.animateSlideContent(slideNumber);
                break;
        }
    }

    animateTeamSections() {
        const teamSections = document.querySelectorAll('.team-section');
        teamSections.forEach((section, index) => {
            section.style.opacity = '0';
            section.style.transform = 'translateY(20px)';
            setTimeout(() => {
                section.style.transition = 'all 0.6s ease';
                section.style.opacity = '1';
                section.style.transform = 'translateY(0)';
            }, index * 200);
        });
    }

    animateAgendaItems() {
        const agendaItems = document.querySelectorAll('.agenda-item');
        agendaItems.forEach((item, index) => {
            item.style.opacity = '0';
            item.style.transform = 'translateX(-30px)';
            setTimeout(() => {
                item.style.transition = 'all 0.5s ease';
                item.style.opacity = '1';
                item.style.transform = 'translateX(0)';
            }, index * 150);
        });
    }

    animateDemoPlaceholder() {
        const demoIcon = document.querySelector('.demo-icon i');
        if (demoIcon) {
            demoIcon.style.animation = 'pulse 2s infinite';
        }
    }

    animateResults() {
        const resultCards = document.querySelectorAll('.result-card');
        resultCards.forEach((card, index) => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            setTimeout(() => {
                card.style.transition = 'all 0.6s ease';
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, index * 200);
        });
    }

    animateSlideContent(slideNumber) {
        const slide = document.querySelector(`[data-slide="${slideNumber}"]`);
        if (slide) {
            const content = slide.querySelector('.slide-content');
            if (content) {
                content.style.opacity = '0';
                content.style.transform = 'translateY(20px)';
                setTimeout(() => {
                    content.style.transition = 'all 0.6s ease';
                    content.style.opacity = '1';
                    content.style.transform = 'translateY(0)';
                }, 100);
            }
        }
    }

    updateSlideDisplay() {
        if (this.currentSlideElement) {
            this.currentSlideElement.textContent = this.currentSlide;
        }
        if (this.totalSlidesElement) {
            this.totalSlidesElement.textContent = this.totalSlides;
        }
    }

    updateProgressBar() {
        const progress = (this.currentSlide / this.totalSlides) * 100;
        if (this.progressFill) {
            this.progressFill.style.width = `${progress}%`;
        }
    }

    updateNavigationButtons() {
        if (this.prevBtn) {
            this.prevBtn.disabled = this.currentSlide === 1;
            this.prevBtn.innerHTML = this.currentSlide === 1 ? 
                '<i class="fas fa-chevron-left"></i><span>Start</span>' : 
                '<i class="fas fa-chevron-left"></i><span>Poprzedni</span>';
        }
        
        if (this.nextBtn) {
            this.nextBtn.disabled = this.currentSlide === this.totalSlides;
            this.nextBtn.innerHTML = this.currentSlide === this.totalSlides ? 
                '<i class="fas fa-check"></i><span>Koniec</span>' : 
                '<i class="fas fa-chevron-right"></i><span>Następny</span>';
        }
    }

    announceSlideChange() {
        const slideTitle = document.querySelector(`[data-slide="${this.currentSlide}"] h1`);
        if (slideTitle) {
            const announcement = document.createElement('div');
            announcement.setAttribute('aria-live', 'polite');
            announcement.setAttribute('aria-atomic', 'true');
            announcement.className = 'sr-only';
            announcement.textContent = `Slajd ${this.currentSlide} z ${this.totalSlides}: ${slideTitle.textContent}`;
            document.body.appendChild(announcement);
            
            setTimeout(() => {
                if (document.body.contains(announcement)) {
                    document.body.removeChild(announcement);
                }
            }, 1000);
        }
    }

    toggleFullscreen() {
        if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen().catch(err => {
                console.log(`Error attempting to enable fullscreen: ${err.message}`);
            });
        } else {
            document.exitFullscreen();
        }
    }

    getPresentationInfo() {
        return {
            title: 'Stanowisko demonstracyjne - przewijarka materiału',
            company: 'B&R Industrial Automation',
            currentSlide: this.currentSlide,
            totalSlides: this.totalSlides,
            progress: Math.round((this.currentSlide / this.totalSlides) * 100)
        };
    }
}

// CSS Animation definitions
const style = document.createElement('style');
style.textContent = `
@keyframes pulse {
    0% { transform: scale(1); }
    50% { transform: scale(1.1); }
    100% { transform: scale(1); }
}

.sr-only {
    position: absolute;
    width: 1px;
    height: 1px;
    padding: 0;
    margin: -1px;
    overflow: hidden;
    clip: rect(0, 0, 0, 0);
    white-space: nowrap;
    border: 0;
}
`;
document.head.appendChild(style);

// Initialize presentation when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    window.brPresentation = new BRPresentation();
    
    console.log('B&R Presentation Keyboard Shortcuts:');
    console.log('→ / Space / PageDown: Next slide');
    console.log('← / PageUp: Previous slide');
    console.log('Home: First slide');
    console.log('End: Last slide');
    console.log('1-8: Jump to slide number');
    console.log('Escape: Toggle fullscreen');
    
    window.presentationInfo = window.brPresentation.getPresentationInfo();
});

// Global helper functions
window.changeSlide = function(direction) {
    if (window.brPresentation) {
        if (direction > 0) {
            window.brPresentation.nextSlide();
        } else {
            window.brPresentation.previousSlide();
        }
    }
};

window.goToSlide = function(slideNumber) {
    if (window.brPresentation) {
        window.brPresentation.goToSlide(slideNumber);
    }
};

// Add print styles for presentation handouts
const printStyle = document.createElement('style');
printStyle.textContent = `
@media print {
    body {
        background: white !important;
        overflow: visible !important;
    }
    
    .slide {
        position: static !important;
        opacity: 1 !important;
        transform: none !important;
        page-break-after: always;
        box-shadow: none !important;
        border: 1px solid #ccc;
        margin-bottom: 20px;
    }
    
    .nav-controls, .progress-bar, .slide-counter {
        display: none !important;
    }
    
    .slide-content {
        padding: 20px !important;
    }
    
    h1 { color: #003366 !important; }
    p, li { color: #333 !important; }
}
`;
document.head.appendChild(printStyle);
